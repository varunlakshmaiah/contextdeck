import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { HOME_DIR, UI_DIR, deleteLayout, levelOfLayout, readSettings, validate, writeLayout, writeSettings } from "./config";
import { askLLM, configuredProviders, providerName, resolveProvider } from "./llm";
import { usefulEntries } from "./menus";
import { SECRET_NAME } from "./secrets";
import type { Engine } from "./engine";
import type { LayoutDef, OverlaySpec } from "./types";

/**
 * Local control API — 127.0.0.1 only, bearer token from ~/.contextdeck/token.
 *
 *   POST /pair       {"client":"Chrome"}  (no token) asks on the deck; returns the token if you press Allow
 *   POST /context/browser {"url","title","browser","focused","incognito"}  from the browser extension
 *   GET  /ui                            the ContextDeck app (local web UI; token in the URL fragment)
 *   GET  /status                       current layout, mode, context, state, key labels
 *   GET  /config                       the full layouts.json
 *   PUT  /layouts/:id                  create/replace one layout (validated, hot-reloads)
 *   DELETE /layouts/:id
 *   POST /flags      {"meeting":true}  set context flags (drive layouts from anything)
 *   POST /state      {"agent":"running"}  set state values shown on keys
 *   POST /mode       {"mode":"color"}
 *   POST /layout     {"id":"resolve"} | {"id":null}
 *   POST /overlay    OverlaySpec (+ "wait": true to block until a key is pressed)
 *   DELETE /overlay
 *   POST /flash      {"key":7,"color":"#22C55E","text":"Done","ms":2000}
 *   POST /press      {"key":3,"device"?,"hold"?}  simulate a key press
 *   GET  /render[?device=]             SVG of every key/dial (the app's live preview)
 *   GET  /devices | /logs | /browser
 *   GET|PUT /settings                  the settings block of config.json
 *   GET  /layouts | /layouts/:id
 *   POST /ui/open                      open the app in your browser
 *   POST /setup      {"force":false,"update":false}  auto-configure the app/site in front (waits; returns the result)
 *   POST /page       {"page":"next"|"prev"|"smart"|"sub"|"app"|"system"|<id>}
 *   POST /reload
 *   GET  /secrets                      declared secrets (names, hosts, where used) and which are missing — never values
 *   POST /secrets    {"name","value"}  store a secret in the OS credential store (values never come back out)
 *   DELETE /secrets/:name
 *   POST /secrets/refresh              re-read the credential store
 *   GET  /menus[?bundleId=..&all=1]    the front app's menu items with real shortcuts
 *   GET  /elgato/tools[?refresh]       actions on the Stream Deck app's "MCP Actions" profile (via @elgato/mcp-server)
 *   POST /elgato/run {"tool","args"}   trigger one
 *   GET  /llm                          providers, which one is in use
 *   POST /llm/use    {"provider":"openrouter"} | {"provider":null}
 *   POST /llm/test   {"provider":"ollama"}     round-trip test (latency + reply)
 */
export function startApi(engine: Engine, port: number, token: string) {
	let pairing = false;
	const server = createServer(async (req, res) => {
		try {
			// The browser extension calls from its own origin; nothing else may (no web page can read the API).
			// DNS-rebinding guard: only answer to our own host names.
			if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(String(req.headers.host ?? ""))) return send(res, 403, { error: "host not allowed" });
			const origin = String(req.headers.origin ?? "");
			if (/^(chrome|moz|safari-web)-extension:\/\//.test(origin)) {
				res.setHeader("access-control-allow-origin", origin);
				res.setHeader("access-control-allow-headers", "authorization, content-type");
				res.setHeader("access-control-allow-methods", "GET, POST, PUT, DELETE");
				res.setHeader("vary", "origin");
			} else if (origin && !/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(origin)) {
				return send(res, 403, { error: "origin not allowed" });
			}
			if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
			const url = new URL(req.url ?? "/", "http://localhost");
			if (req.method === "GET" && (url.pathname === "/ui" || url.pathname.startsWith("/ui/"))) return serveUi(res, url.pathname);
			if (url.pathname === "/favicon.ico") { res.writeHead(204); return res.end(); }
			if (req.method === "POST" && url.pathname === "/pair") {
				if (pairing) return send(res, 409, { ok: false, error: "Another pairing request is waiting on the deck" });
				const client = String(((await readJson(req)) as { client?: string }).client ?? "A client").replace(/[^\w .()-]/g, "").slice(0, 40) || "A client";
				pairing = true;
				try {
					const ok = await engine.requestPair(client);
					return send(res, ok ? 200 : 403, ok ? { ok: true, token } : { ok: false, error: "Denied on the deck" });
				} finally { pairing = false; }
			}
			if (req.headers.authorization !== `Bearer ${token}`) return send(res, 401, { error: "unauthorized" });
			const body = req.method === "GET" || req.method === "DELETE" ? {} : await readJson(req);
			const route = `${req.method} ${url.pathname}`;
			const layoutMatch = /^\/layouts\/([\w.-]+)$/.exec(url.pathname);

			if (route === "GET /status") return send(res, 200, engine.snapshot());
			if (route === "POST /context/browser") {
				const b = body as { url?: string; title?: string; browser?: string; focused?: boolean; incognito?: boolean };
				engine.setBrowserReport({ url: String(b.url ?? "").slice(0, 2000), title: String(b.title ?? "").slice(0, 300), browser: b.browser ? String(b.browser).slice(0, 40) : undefined, focused: b.focused !== false, incognito: !!b.incognito });
				return send(res, 200, { ok: true });
			}
			if (route === "GET /config") return send(res, 200, engine.config);
			if (layoutMatch && req.method === "PUT") {
				const layout = { ...(body as unknown as LayoutDef), id: layoutMatch[1] };
				const existed = engine.config.layouts.some((l) => l.id === layout.id);
				const file = writeLayout(layout);
				engine.sources[layout.id] = file;
				engine.setConfig({ ...engine.config, layouts: [...engine.config.layouts.filter((l) => l.id !== layout.id), layout] }, []);
				return send(res, 200, { ok: true, created: !existed, file });
			}
			if (layoutMatch && req.method === "DELETE") {
				const removed = deleteLayout(layoutMatch[1]);
				engine.setConfig({ ...engine.config, layouts: engine.config.layouts.filter((l) => l.id !== layoutMatch[1]) }, []);
				return send(res, 200, { ok: true, removed });
			}
			if (route === "POST /setup") {
				const b = body as { force?: boolean; update?: boolean };
				return send(res, 200, await engine.runSetup({ force: !!b.force, update: !!b.update, index: engine.settings.setupSlot ?? 6 }));
			}
			if (route === "POST /page") { engine.goPage((body as { page?: string | number }).page ?? "next"); return send(res, 200, engine.snapshot().page); }
			if (route === "POST /reload") { engine.reloadConfig(); return send(res, 200, { ok: true, errors: engine.configErrors }); }
			if (route === "POST /secrets") {
				const { name, value } = body as { name?: string; value?: string };
				if (!name || !value) return send(res, 400, { ok: false, error: "name and value are required" });
				const isProvider = configuredProviders(engine.settings).includes(name) || !!resolveProvider(engine.settings, name);
				if (!SECRET_NAME.test(name) && !isProvider) return send(res, 400, { ok: false, error: "Secret names are UPPER_SNAKE_CASE (e.g. GITHUB_TOKEN), or an LLM provider id (e.g. openrouter)" });
				if (SECRET_NAME.test(name)) await engine.deps.secrets.set(name, value); else await engine.os.secretSet(name, value);
				engine.deps.secrets.forget?.(name);
				await engine.refreshMissingSecrets();
				return send(res, 200, { ok: true, missing: engine.snapshot().missingSecrets });
			}
			const secretMatch = /^\/secrets\/([\w.-]+)$/.exec(url.pathname);
			if (secretMatch && req.method === "DELETE") {
				await engine.os.secretDelete(secretMatch[1]);
				engine.deps.secrets.forget?.(secretMatch[1]);
				await engine.refreshMissingSecrets();
				return send(res, 200, { ok: true, removed: secretMatch[1] });
			}
			if (route === "POST /secrets/refresh") { engine.deps.secrets.forget?.(); await engine.refreshMissingSecrets(); return send(res, 200, { missing: engine.snapshot().missingSecrets }); }
			if (route === "GET /secrets") {
				const out: Record<string, { description?: string; url?: string; hosts?: string[]; usedBy: string[]; stored: boolean }> = {};
				const add = (name: string, by: string, d?: { description?: string; url?: string; hosts?: string[] }) => {
					out[name] ??= { usedBy: [], stored: false };
					if (d) Object.assign(out[name], { description: d.description, url: d.url, hosts: d.hosts });
					if (!out[name].usedBy.includes(by)) out[name].usedBy.push(by);
				};
				for (const [n, d] of Object.entries(engine.settings.secrets ?? {})) add(n, "config", d);
				for (const l of engine.config.layouts) {
					for (const [n, d] of Object.entries(l.secrets ?? {})) add(n, l.id, d);
					const all = [...(l.keys ?? []), ...(l.dials ?? []), ...(l.pages ?? []).flatMap((p) => p.keys ?? [])];
					for (const k of all) for (const n of k?.requires ?? []) add(n, l.id);
				}
				for (const n of Object.keys(out)) out[n].stored = !!(await engine.deps.secrets.get(n).catch(() => undefined));
				return send(res, 200, { secrets: out, missing: Object.entries(out).filter(([, v]) => !v.stored).map(([k]) => k) });
			}
			if (route === "GET /elgato/tools") {
				if (!engine.elgato.available) return send(res, 200, { ok: false, available: false, error: process.platform === "linux" ? "Elgato's MCP server needs the Stream Deck app (macOS or Windows)" : "turned off in settings.elgato" });
				try { return send(res, 200, { ok: true, tools: await engine.elgato.listTools(url.searchParams.has("refresh")) }); }
				catch (e) { return send(res, 200, { ok: false, error: (e as Error).message }); }
			}
			if (route === "POST /elgato/run") {
				const b = body as { tool?: string; args?: Record<string, unknown> };
				if (!b.tool) return send(res, 400, { ok: false, error: "tool is required" });
				try { return send(res, 200, { ok: true, result: await engine.elgato.call(b.tool, b.args ?? {}) }); }
				catch (e) { return send(res, 200, { ok: false, error: (e as Error).message }); }
			}
			if (route === "GET /llm") {
				return send(res, 200, {
					inUse: engine.llm, default: engine.settings.llm ?? "anthropic", override: engine.llmOverride, setup: engine.settings.setupLlm ?? engine.llm, fallback: engine.settings.fallbackLlm ?? null,
					providers: configuredProviders(engine.settings).map((id) => {
						const p = resolveProvider(engine.settings, id)!;
						return { id, name: providerName(engine.settings, id), type: p.def.type, baseUrl: p.def.baseUrl, model: p.def.model ?? null, local: !!p.def.noKey };
					}),
				});
			}
			if (route === "POST /llm/use") {
				const id = (body as { provider?: string | null }).provider ?? null;
				if (id && !resolveProvider(engine.settings, id)) return send(res, 400, { error: `unknown provider "${id}"` });
				engine.selectLlm(id);
				return send(res, 200, { inUse: engine.llm });
			}
			if (route === "POST /llm/test") {
				const asked = (body as { provider?: string }).provider;
				// No provider named: test every role the deck uses (AI keys, ✨ Set up, fallback), each once.
				const roles: [string, string][] = asked
					? [[asked, "requested"]]
					: ([[engine.llm, "AI keys (llm)"], [engine.settings.setupLlm ?? engine.llm, "✨ Set up (setupLlm)"], [engine.settings.fallbackLlm ?? "", "fallback (fallbackLlm)"]] as [string, string][]).filter(([id]) => id);
				const byId = new Map<string, string[]>();
				for (const [id, role] of roles) byId.set(id, [...(byId.get(id) ?? []), role]);
				const results = [];
				for (const [id, usedFor] of byId) {
					const t0 = Date.now();
					try {
						const r = await askLLM(engine.settings, { provider: id, prompt: "Reply with exactly: OK", system: "You are a connectivity test. Reply with exactly: OK", maxTokens: 20 });
						results.push({ ok: true, provider: id, usedFor, model: r.model, ms: Date.now() - t0, reply: r.text.slice(0, 80) });
					} catch (e) {
						results.push({ ok: false, provider: id, usedFor, ms: Date.now() - t0, error: (e as Error).message });
					}
				}
				return send(res, 200, asked ? results[0] : { ok: results.every((r) => r.ok), results });
			}
			if (route === "GET /menus") {
				const bundleId = url.searchParams.get("bundleId") || engine.ctx.bundleId;
				if (!bundleId) return send(res, 400, { error: "no app in front" });
				const all = await engine.os.scanMenus(bundleId);
				const entries = url.searchParams.get("all") ? all : usefulEntries(all, engine.ctx.app);
				return send(res, 200, { bundleId, count: entries.length, withShortcuts: entries.filter((e) => e.chord).length, entries: entries.map((e) => ({ path: e.path.join(" > "), chord: e.chord ?? null })) });
			}
			if (route === "POST /flags") {
				for (const [k, v] of Object.entries(body)) engine.setFlag(k, Boolean(v));
				return send(res, 200, engine.snapshot().context.flags);
			}
			if (route === "POST /state") {
				for (const [k, v] of Object.entries(body)) engine.setState(k, v);
				return send(res, 200, { ok: true });
			}
			if (route === "POST /mode") { engine.setMode(String((body as { mode: string }).mode)); return send(res, 200, engine.snapshot()); }
			if (route === "POST /layout") { engine.forceLayout((body as { id: string | null }).id ?? null); return send(res, 200, engine.snapshot()); }
			if (route === "POST /overlay") {
				const spec = body as OverlaySpec & { wait?: boolean; waitMs?: number };
				const wantsReturn = spec.wait ? { onPick: spec.onPick ?? "return" } : {};
				const id = engine.showOverlay({ ...spec, ...wantsReturn } as OverlaySpec);
				if (!spec.wait) return send(res, 200, { id });
				const result = await engine.waitForPick(id, Math.min(spec.waitMs ?? 120_000, 600_000));
				if (engine.overlay?.id === id) engine.closeOverlay(null);
				return send(res, 200, { id, ...result });
			}
			if (route === "DELETE /overlay") { engine.closeOverlay(null); return send(res, 200, { ok: true }); }
			if (route === "POST /flash") {
				const b = body as { key?: number; color?: string; text?: string; ms?: number };
				engine.flash(b.key ?? 7, b.color, b.text, b.ms);
				return send(res, 200, { ok: true });
			}
			if (route === "POST /press") {
				const b = body as { key: number; device?: string; hold?: boolean };
				const k = Number(b.key);
				engine.keyDown(k, b.device);
				setTimeout(() => engine.keyUp(k, b.device), b.hold ? (engine.settings.holdMs ?? 500) + 150 : 60);
				return send(res, 200, { ok: true });
			}
			// ---------- the app (local web UI) ----------
			if (route === "GET /render") return send(res, 200, engine.preview(url.searchParams.get("device") ?? undefined));
			if (route === "GET /devices") return send(res, 200, { devices: engine.devices() });
			if (route === "GET /logs") return send(res, 200, { logs: engine.logs });
			if (route === "POST /ui/open") { await engine.openUi(); return send(res, 200, { ok: true }); }
			if (route === "GET /browser") {
				const r = engine.browserReport;
				return send(res, 200, { connected: !!r, ageSeconds: r ? Math.round((Date.now() - r.at) / 1000) : null, browser: r?.browser ?? null, focused: r?.focused ?? null, extensionFolder: join(HOME_DIR, "extension") });
			}
			if (route === "GET /settings") return send(res, 200, { settings: readSettings() });
			if (route === "PUT /settings") {
				const s = (body as { settings?: unknown }).settings;
				if (!s || typeof s !== "object" || Array.isArray(s)) return send(res, 400, { ok: false, error: "settings must be an object" });
				const errors = validate({ ...engine.config, settings: s });
				if (errors.length) return send(res, 400, { ok: false, errors });
				writeSettings(s as Record<string, unknown>);
				engine.reloadConfig();
				return send(res, 200, { ok: true, errors: engine.configErrors });
			}
			if (route === "GET /layouts") {
				return send(res, 200, { layouts: engine.config.layouts.map((l) => ({ id: l.id, name: l.name ?? l.id, level: levelOfLayout(l), color: l.color, file: engine.sources[l.id] ?? null, generated: l.generated ?? null, match: l.match ?? null, keys: (l.keys ?? []).filter(Boolean).length, pages: (l.pages ?? []).map((p) => p.name) })) });
			}
			if (layoutMatch && req.method === "GET") {
				const l = engine.config.layouts.find((x) => x.id === layoutMatch[1]);
				return l ? send(res, 200, l) : send(res, 404, { error: "no such layout" });
			}
			return send(res, 404, { error: `no route ${route}` });
		} catch (e) {
			return send(res, 400, { error: (e as Error).message });
		}
	});
	server.on("error", (e) => engine.log(`API error: ${e.message}`));
	engine.uiUrl = `http://127.0.0.1:${port}/ui#token=${token}`;
	server.listen(port, "127.0.0.1", () => engine.log(`API on http://127.0.0.1:${port}`));
	return server;
}

function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
	return new Promise((resolve, reject) => {
		let data = "";
		req.on("data", (c) => { data += c; if (data.length > 2_000_000) reject(new Error("body too large")); });
		req.on("end", () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error("invalid JSON body")); } });
		req.on("error", reject);
	});
}

/** The app is one self-contained page; the token travels in the URL fragment, which browsers never send. */
function serveUi(res: ServerResponse, path: string) {
	if (path !== "/ui" && path !== "/ui/") { res.writeHead(404); return res.end(); }
	try {
		const html = readFileSync(join(UI_DIR, "index.html"));
		res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "content-security-policy": "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'", "x-frame-options": "DENY" });
		res.end(html);
	} catch {
		res.writeHead(404, { "content-type": "text/plain" });
		res.end("The ContextDeck app isn't in this build.");
	}
}

function send(res: ServerResponse, status: number, body: unknown) {
	res.writeHead(status, { "content-type": "application/json" });
	res.end(JSON.stringify(body));
}
